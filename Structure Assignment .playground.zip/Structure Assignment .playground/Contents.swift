import UIKit

// Labeling the variables
struct CarEngResolution {
var car1 = 200 //horsepower
var car2 = 429 //horsepower
var car3 = 1000 //horsepower

}
let engine = CarEngResolution()

print("From the options above the first car is a Toyota Camary and has a horsepower rate of \(engine.car1), A Mercedes-AMG has a horsepower rate of \(engine.car2), The last car in my list is a v8 which has a horsepower rate of \(engine.car3)." )
print("The car I want to choose is the Mercedes-AMG because the horsepower rate is \(engine.car2) which not the lowest or highest. It is in the middle.")
